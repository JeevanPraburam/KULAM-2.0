# Kulam 2.0 🌊

**From dying rural water bodies to smart climate assets.**

Kulam 2.0 is an early-stage web-app prototype concept for helping communities register rural water bodies, report issues and track restoration activity.

## Features

- Dashboard of registered water bodies
- Add kanmais, temple tanks, village ponds and other water bodies
- Submit issue reports for siltation, pollution, blocked inlets/outlets, damaged bunds and water scarcity
- Update restoration status and manually entered water observations
- Recent report activity list
- SQLite database for local persistence
- Responsive layout for desktop and mobile browsers

## Important prototype notes

- The starter records are fictional demo entries, not verified real-world locations.
- The app does not currently connect to real sensors, weather services, maps, official government records, user accounts or notifications.
- Water observations are manually entered and are not independently verified.
- This is a prototype, not an official monitoring or emergency service.

## Run locally

Requires Python 3.10 or newer.

### 1. Clone your repository

```bash
git clone https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
cd YOUR-REPOSITORY
```

### 2. Create and activate a virtual environment

Windows PowerShell:

```powershell
py -m venv .venv
.venv\\Scripts\\Activate.ps1
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install -r requirements.txt
```

### 4. Start the app

```bash
python app.py
```

Open http://127.0.0.1:5000 in your browser.

The SQLite database `kulam2.db` is created automatically on first run and is intentionally excluded from Git.

## Suggested GitHub repository structure

```text
kulam2/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Suggested next steps

1. Replace demo entries with verified local water-body data.
2. Add authentication and role-based access before public deployment.
3. Add photo uploads with file validation and safe storage.
4. Add a map with verified coordinates.
5. Add measured water-level and rainfall data sources.
6. Test with a local community and make reporting accessible in Tamil.

## Security before deployment

The development server and debug mode are for local testing only. Before deploying publicly, turn off debug mode, use a secure environment-based secret key, add authentication/authorization for record updates, apply CSRF protection, and choose persistent database and file storage.
