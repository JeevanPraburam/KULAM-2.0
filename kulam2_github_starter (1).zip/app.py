from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
app.secret_key = "change-this-secret-before-deployment"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "kulam2.db"

ISSUE_TYPES = ["Siltation", "Pollution", "Blocked inlet/outlet", "Damaged bund", "Water scarcity", "Other"]
STATUSES = ["Needs attention", "Monitoring", "Restoration in progress", "Restored"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS water_bodies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                village TEXT NOT NULL,
                body_type TEXT NOT NULL,
                water_level TEXT NOT NULL DEFAULT 'Not recorded',
                status TEXT NOT NULL DEFAULT 'Needs attention',
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                water_body_id INTEGER NOT NULL,
                issue_type TEXT NOT NULL,
                description TEXT NOT NULL,
                reporter TEXT NOT NULL DEFAULT 'Community member',
                created_at TEXT NOT NULL,
                FOREIGN KEY(water_body_id) REFERENCES water_bodies(id)
            )
        """)
        count = db.execute("SELECT COUNT(*) FROM water_bodies").fetchone()[0]
        if count == 0:
            samples = [
                ("Periya Kanmai", "Demo Village", "Kanmai", "Not recorded", "Monitoring",
                 "Sample entry for demonstration only."),
                ("Amman Temple Tank", "Demo Village", "Temple tank", "Not recorded", "Needs attention",
                 "Sample entry for demonstration only."),
                ("South Kulam", "Demo Village", "Village pond", "Not recorded", "Restoration in progress",
                 "Sample entry for demonstration only.")
            ]
            db.executemany("""
                INSERT INTO water_bodies
                (name, village, body_type, water_level, status, notes, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, [(*s, datetime.now().strftime("%Y-%m-%d %H:%M")) for s in samples])


@app.route("/")
def index():
    with get_db() as db:
        bodies = db.execute("""
            SELECT w.*, (SELECT COUNT(*) FROM reports r WHERE r.water_body_id = w.id) AS report_count
            FROM water_bodies w ORDER BY w.id DESC
        """).fetchall()
        reports = db.execute("""
            SELECT r.*, w.name AS water_body_name
            FROM reports r JOIN water_bodies w ON w.id = r.water_body_id
            ORDER BY r.id DESC LIMIT 5
        """).fetchall()
        total_reports = db.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
    return render_template("index.html", bodies=bodies, reports=reports,
                           total_reports=total_reports, statuses=STATUSES)


@app.route("/water-bodies/add", methods=["POST"])
def add_water_body():
    name = request.form.get("name", "").strip()
    village = request.form.get("village", "").strip()
    body_type = request.form.get("body_type", "").strip()
    notes = request.form.get("notes", "").strip()

    if not name or not village or body_type not in ["Kanmai", "Temple tank", "Village pond", "Lake", "Other"]:
        flash("Please fill in the required fields with valid values.", "error")
        return redirect(url_for("index"))

    with get_db() as db:
        db.execute("""
            INSERT INTO water_bodies (name, village, body_type, notes, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (name, village, body_type, notes, datetime.now().strftime("%Y-%m-%d %H:%M")))
    flash("Water body added successfully.", "success")
    return redirect(url_for("index"))


@app.route("/reports/add", methods=["POST"])
def add_report():
    body_id = request.form.get("water_body_id", type=int)
    issue_type = request.form.get("issue_type", "")
    description = request.form.get("description", "").strip()
    reporter = request.form.get("reporter", "").strip() or "Community member"

    if not body_id or issue_type not in ISSUE_TYPES or len(description) < 8:
        flash("Choose a water body and issue type, and enter at least 8 characters of detail.", "error")
        return redirect(url_for("index"))

    with get_db() as db:
        exists = db.execute("SELECT id FROM water_bodies WHERE id = ?", (body_id,)).fetchone()
        if not exists:
            flash("That water body could not be found.", "error")
            return redirect(url_for("index"))
        db.execute("""
            INSERT INTO reports (water_body_id, issue_type, description, reporter, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (body_id, issue_type, description, reporter[:80], datetime.now().strftime("%Y-%m-%d %H:%M")))
    flash("Issue report saved. Thank you for helping protect local water bodies.", "success")
    return redirect(url_for("index"))


@app.route("/water-bodies/<int:body_id>/status", methods=["POST"])
def update_status(body_id):
    status = request.form.get("status", "")
    water_level = request.form.get("water_level", "").strip() or "Not recorded"
    if status not in STATUSES:
        flash("Please choose a valid status.", "error")
        return redirect(url_for("index"))
    with get_db() as db:
        db.execute("UPDATE water_bodies SET status = ?, water_level = ? WHERE id = ?",
                   (status, water_level[:80], body_id))
    flash("Water body record updated.", "success")
    return redirect(url_for("index"))


@app.route("/health")
def health():
    return {"status": "ok", "app": "Kulam 2.0"}


init_db()

if __name__ == "__main__":
    app.run(debug=True)
